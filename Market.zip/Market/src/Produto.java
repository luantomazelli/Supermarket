import java.util.*;

public class Produto{
   private String nomeProduto;
   private int lote;
   private int estoque;
   GregorianCalendar dataFab, dataVal;
   private double valorAquisicao;
   private double valorVenda;
   private String fornecedor;
   
   public Produto(String nP, int l, double vA, double vV, String f, int e, GregorianCalendar dV, GregorianCalendar dF){
       setNome(nP);
       setLote(l);
       setValorAquisicao(vA);
       setValorVenda(vV);
       setFornecedor(f);
       setEstoque(e);
       setDataVal(dV);
       setDataFab(dF);
   }
   
   public void setNome(String nP){
       nomeProduto = nP;
       
   }
   
   public void setLote(int l){
       lote = l;
   }
   
   public void setValorAquisicao(double vA){
       valorAquisicao = vA;
   }
    
   public void setValorVenda(double vV){
       valorVenda = vV;
   }
   
   public void setFornecedor(String f){
       fornecedor = f;
   }
   
   public void setEstoque(int e){
        estoque = e;
   }
    
   public int getEstoque(){
        return estoque;
   }
   
   public void setDataVal(GregorianCalendar d){
        dataVal = d;
   }
   
   public void setDataFab(GregorianCalendar d){
        dataFab = d;
   }   
   
   public String getNome(){
       return nomeProduto; 
   }
   
   public int getLote(){
       return lote;
   }
   
   public double getValorAquisicao(){
       return valorAquisicao;
   }
    
   public double getValorVenda(){
       return valorVenda;
   }
   
   public String getFornecedor(){
       return fornecedor;
   }   
   
   public String getDataVenc(){
        return dataVal.get(Calendar.DAY_OF_MONTH)+"/"+dataVal.get(Calendar.MONTH)+"/"+dataVal.get(Calendar.YEAR);
   }    
   
   public String getDataFab(){
        return dataFab.get(Calendar.DAY_OF_MONTH)+"/"+dataFab.get(Calendar.MONTH)+"/"+dataFab.get(Calendar.YEAR);
   }       
   
    public String toString(){
        return "\nNome Produto: "+getNome()+
               "\nLote: "+getLote()+
               "\nValor de Aquisi��o: "+getValorAquisicao()+
               "\nValor de Venda: "+getValorVenda()+
               "\nFornecedor: "+getFornecedor()+
               "\nEstoque: "+getEstoque();
            }   
}