import java.util.*;


public class ListaQuantidade{
    
    private ArrayList<String> listaQ;
    
    
    public ListaQuantidade(int m){
        listaQ = new ArrayList<String>(m);
    }
    public int tamanhoListaQ(){
        return listaQ.size();
    }
    
    public boolean adicionaQuantidade(String p){
        return listaQ.add(p);
    }
    
    public String buscaQuantidade(int q){
        return listaQ.get(q);
    }    
    
    public String listQuantidade(){
        String str="\n";
        for(int i=0;i<listaQ.size();i++){
            str=str+"\nQuantidade: \n"+listaQ.get(i).toString();
        }
        return str;
    }
    
}
    