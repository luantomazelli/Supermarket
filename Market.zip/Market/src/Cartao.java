public class Cartao{
    private int nroCartao;
    private int diaVencimento;
    
    public Cartao(int c, int v){
        setNroCartao(c);
        setDiaVencimento(v);
    }
    
    public void setNroCartao(int c){
        nroCartao = c;
    }
    
    public void setDiaVencimento(int v){
        diaVencimento = v;
    }
    
    public int getNroCartao(){
        return nroCartao;
    }
    
    public int getDiaVencimento(){
        return diaVencimento;
    }    
    
    public String toString(){
        return "\nN�mero Cart�o: "+getNroCartao()+
               "\nDia Vencimento: "+getDiaVencimento();
            }
    
    //public double totalPagar
}
    
    