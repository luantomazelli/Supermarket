import java.util.*;


public class ListaProduto{
    
    private ArrayList<Produto> listaP;
    
    
    public ListaProduto(int m){
        listaP = new ArrayList<Produto>(m);
    }
    
    public int tamanhoListaP(){
        return listaP.size();
    }
    
    public boolean adicionaProduto(Produto p){
        return listaP.add(p);
    }
    
    public Produto buscaProduto(int t){
        return listaP.get(t);
    }

    public boolean removeProdutoNome(String n){
        boolean removeu = false;
        for (int i=0;i<listaP.size();i++){
            Produto p = listaP.get(i);
            if(p.getNome().equals(n)){
                listaP.remove(i);
                removeu=true;
                break;
            }
        }
        return removeu;
    }    
    
    public Produto pesquisaProduto(String n){
        int c=-1;
        for (int i=0;i<listaP.size();i++){
            Produto p = listaP.get(i);
            if (p.getNome().equals(n)){
                c=i;
                break;
            }
        }
        if(c!=-1)return listaP.get(c);
        else return null;
    }    
    
    public Produto pesquisaProdutoLote(int n){
        int c=-1;
        for (int i=0;i<listaP.size();i++){
            Produto p = listaP.get(i);
            if (p.getLote()==n){
                c=i;
                break;
            }
        }
        if(c!=-1)return listaP.get(c);
        else return null;
    }        
    
    
    public String listProduto(){
        String str="\n";
        for(int i=0;i<listaP.size();i++){
            str=str+"\nProduto: \n"+listaP.get(i).toString();
        }
        return str;
    }    
    
  /*  public double gastoProduto(){
        double d=0;
        for (int i=0;i<listaP.size();i++){
            Produto p = listaP.get(i);
            d=d+p.getValorAquisicao()*p.getEstoque();
        }
        return d;
    }*/

}