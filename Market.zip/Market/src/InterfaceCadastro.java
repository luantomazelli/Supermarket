import java.util.*;

public class InterfaceCadastro{
    public void Cadastro(){
        ListaCompra listagem = new ListaCompra(10);
        ListaCliente listaC = new ListaCliente(10);
        ListaProduto listaP = new ListaProduto(10);
        ListaProduto listaPC = new ListaProduto(10);
        ListaQuantidade listaQ = new ListaQuantidade(10);
        
        Scanner e = new Scanner(System.in);
        int opcao=0,op=0;
        double d1,d2,total=0, zero=0;
        String vazio="";
        boolean bo=false;
        String s1,s2,s3,s4,s5,s6,dN="",res,cel,nomeCliente="";
        GregorianCalendar date, dataFab, dataVal;
        int dia, mes, ano, i1, i2;
        Telefone tres, tcel;
        Cliente c;
        Produto p;
        Compra com;
        Cartao car;
        
        do{
            
            System.out.println("\nSupermercado - Menu de Op��es:");
            System.out.println("1. Cadastrar clientes, produtos e vendas de produtos para clientes");
            System.out.println("2. Excluir clientes e produtos");
            System.out.println("3. Procurar clientes pelo seu nome e pelo cpf");
            System.out.println("4. Procurar produtos pelo seu nome e n�mero de lote");
            System.out.println("5. Gerar a fatura do cart�o do cliente com todas as compras e, ao final, o total a pagar");
            System.out.println("6. Gerar uma lista dos clientes inativos (que n�o compraram no m�s corrente");
            System.out.println("7. Listar todos os produtos do estoque");
            System.out.println("8. Gerar um desconto de 10% nas compras para aniversariantes do m�s");
            System.out.println("9. Gerar um relat�rio com o faturamento mensal do supermercado");
            System.out.println("Informe a op��o (0 para sair): ");
            opcao=e.nextInt();
            
            switch(opcao){
                case 1: System.out.println("1- Clientes\n2- Produtos\n3- Vendas");
                        op=e.nextInt();
                        if (op==1){
                            System.out.println("Nome: ");
                            s1=e.nextLine();
                            s1=e.nextLine();
                            System.out.println("Cpf: ");
                            s2=e.nextLine();
                            System.out.println("Endere�o: ");
                            s3=e.nextLine();
                            System.out.println("Cidade: ");
                            s4=e.nextLine();
                            System.out.println("Estado: ");
                            s5=e.nextLine();
                            System.out.println("Bairro: ");
                            s6=e.nextLine();
                                //while ((niver.charAt(2)!='/')||(niver.charAt(5)!='/')||(niver.length()!=10)){
                            System.out.println("Digite a data de nascimento (dd/mm/aaaa)");                            
                            dN=e.nextLine();
                                //}
                            //dN=e.nextLine();
                            dia=Integer.parseInt(dN.charAt(0)+""+dN.charAt(1));
                            mes=Integer.parseInt(dN.charAt(3)+""+dN.charAt(4));
                            ano=Integer.parseInt(dN.charAt(6)+""+dN.charAt(7)+""+dN.charAt(8)+""+dN.charAt(9));
                            date = new GregorianCalendar(ano, mes, dia);
                                //while ((com.length()!=11)||(com.charAt(2)!='-')){
                            System.out.println("Telefone Residencial: ");
                            res=e.nextLine();
                                //}
                                //while ((com.length()!=11)||(com.charAt(2)!='-')){                        
                            System.out.println("Telefone Celular: ");
                            cel=e.nextLine();        
                                //}
                            tres=new Telefone(res);
                            tcel=new Telefone(cel);
                            System.out.println("Informe o n�mero do Cart�o de Cr�dito: ");
                            i1=e.nextInt();
                            System.out.println("Informe o dia do vencimento do cart�o: ");
                            i2=e.nextInt();
                            car=new Cartao(i1,i2);
                            c = new Cliente(s2, s1, s3, tres, tcel, s4, s5, s6, date, car);
                            listaC.adicionaCliente(c);
                            break;
                        }
                        if(op==2){
                            System.out.println("Nome: ");
                            s1=e.nextLine();
                            s1=e.nextLine();
                            System.out.println("Lote: ");
                            i1=e.nextInt();
                            System.out.println("Estoque de Produtos: ");
                            i2=e.nextInt();
                            System.out.println("Valor Aquisi��o: ");
                            d1=e.nextDouble();
                            System.out.println("Valor Venda: ");
                            d2=e.nextDouble();
                            System.out.println("Fornecedor: ");
                            s2=e.nextLine();
                            s2=e.nextLine();
                            System.out.println("Digite a data de fabrica��o (dd/mm/aaaa)");                            
                            dN=e.nextLine();
                                //}
                            //dN=e.nextLine();
                            dia=Integer.parseInt(dN.charAt(0)+""+dN.charAt(1));
                            mes=Integer.parseInt(dN.charAt(3)+""+dN.charAt(4));
                            ano=Integer.parseInt(dN.charAt(6)+""+dN.charAt(7)+""+dN.charAt(8)+""+dN.charAt(9));
                            dataFab = new GregorianCalendar(ano, mes, dia);    
                            System.out.println("Digite a data de validade (dd/mm/aaaa)");                            
                            dN=e.nextLine();
                                //}
                            //dN=e.nextLine();
                            dia=Integer.parseInt(dN.charAt(0)+""+dN.charAt(1));
                            mes=Integer.parseInt(dN.charAt(3)+""+dN.charAt(4));
                            ano=Integer.parseInt(dN.charAt(6)+""+dN.charAt(7)+""+dN.charAt(8)+""+dN.charAt(9));
                            dataVal = new GregorianCalendar(ano, mes, dia);
                            p = new Produto(s1, i1, d1, d2, s2, i2, dataVal, dataFab);
                            listaP.adicionaProduto(p);
                            break;
                            
                            }
                        if(op==3){
                            int aux=1;
                            while(aux!=0){
                                System.out.println("Informe o nome do produto: ");
                                s1=e.nextLine();
                                s1=e.nextLine();
                                Produto pAux=listaP.pesquisaProduto(s1);
                                if (pAux!=null){ listaPC.adicionaProduto(pAux);
                                                 System.out.println("Informe a quantidade: ");
                                                 //System.out.println(pAux.getEstoque());
                                                 //do
                                                 s3=e.nextLine();
                                                 //s2=Integer.parseInt(i1);
                                                 //while(i>0);
                                                 listaQ.adicionaQuantidade(s3);
                                                 pAux.setEstoque(pAux.getEstoque()-Integer.parseInt(s3));
                                                 //System.out.println(pAux.getEstoque());
                                                 total=total+(pAux.getValorVenda()*Integer.parseInt(s3));
                                                }
                                else System.out.println("Produto n�o encontrado.");
                                System.out.println("Mais algum produto? (1 para sim; 0 para n�o)");
                                aux=e.nextInt();
                            }
                            System.out.println("A compra ser� feita por Cart�o (1), Cheque (2) ou Dinheiro (3)?");
                            int teste=e.nextInt();
                            if(teste==3){
                                System.out.println("Total a pagar: "+total);
                                System.out.println("Qual o dinheiro total?");
                                d1=e.nextDouble();
                                d2=d1-total;
                                System.out.println("O troco �: "+d2);
                                System.out.println("Qual o nome do cliente?");
                                nomeCliente=e.nextLine();
                                nomeCliente=e.nextLine();
                                c=listaC.pesquisaCliente(nomeCliente);
                                com = new Compra(d1, d2, listaPC, listaQ, total, c, zero, vazio, nomeCliente);
                                listagem.adicionaCompra(com);
                                
                            }
                            if(teste==2){
                                System.out.println("Total a pagar: "+total);
                                System.out.println("Qual � o valor do cheque?");
                                d1=e.nextDouble();
                                d1=e.nextDouble();
                                d2=d1-total;
                                System.out.println("O troco �: "+d2);
                                System.out.println("Qual o nome do cliente?");
                                nomeCliente=e.nextLine();
                                c=listaC.pesquisaCliente(nomeCliente);
                                com = new Compra(d1, d2, listaPC, listaQ, total, c, zero, nomeCliente, vazio);
                                listagem.adicionaCompra(com);
                            }            
                            if(teste==1){
                                System.out.println("Total a pagar: "+total);
                                System.out.println("Qual o n�mero do cart�o?");
                                i1=e.nextInt();
                                Cliente client;
                                client=listaC.pesquisaClienteCartao(i1);
                                com = new Compra(total, 0, listaPC, listaQ, total, client, zero, vazio, vazio);
                                listagem.adicionaCompra(com);                                
                            }
                            //System.out.println("\n"+listagem.listCompra());
                            //s1=e.nextLine();
                            //System.out.println("\n"+listaC.listCliente());
                            //s1=e.nextLine();
                            break;
                            
                            
                       
                        }
                case 2: System.out.println("1- Clientes\n2- Produtos");
                        op=e.nextInt();
                        if (op==1){
                            System.out.println("Informe o nome do cliente: ");
                            s2=e.nextLine();
                            s2=e.nextLine();
                            bo=listaC.removeClienteNome(s2);
                            if (bo) System.out.println("Cadastro removido");
                            else System.out.println("Cadastro inexistente");
                        }
                        else
                        if(op==2){
                            System.out.println("Informe o nome do produto: ");
                            s2=e.nextLine();
                            s2=e.nextLine();
                            bo=listaP.removeProdutoNome(s2);
                            if (bo) System.out.println("Cadastro removido");
                            else System.out.println("Cadastro inexistente");
                        }
                        else
                            System.out.println("Op��o Inv�lida!");
                        break;
                        
                case 3: System.out.println("1- Nome\n2- Cpf");
                        op=e.nextInt();
                        if (op==1){
                            System.out.println("Informe o nome do cliente: ");
                            s2=e.nextLine();
                            s2=e.nextLine();
                            c=listaC.pesquisaCliente(s2);
                            if (c!=null) System.out.println(c);
                            else System.out.println("Cadastro n�o encontrado");
                        }
                        else
                        if(op==2){
                            System.out.println("Informe o cpf do cliente: ");
                            s2=e.nextLine();
                            s2=e.nextLine();
                            c=listaC.pesquisaClienteCpf(s2);
                            if (c!=null) System.out.println(c);
                            else System.out.println("Cadastro n�o encontrado");
                        }
                        else
                            System.out.println("Op��o Inv�lida!");
                        break;
                        
                case 4: System.out.println("1- Nome Produto\n2- Lote");
                        op=e.nextInt();
                        if (op==1){
                            System.out.println("Informe o nome do produto: ");
                            s2=e.nextLine();
                            s2=e.nextLine();
                            p=listaP.pesquisaProduto(s2);
                            if (p!=null) System.out.println(p);
                            else System.out.println("Cadastro n�o encontrado");
                        }
                        else
                        if(op==2){
                            System.out.println("Informe o lote do produto: ");
                            i1=e.nextInt();
                            p=listaP.pesquisaProdutoLote(i1);
                            if (p!=null) System.out.println(p);
                            else System.out.println("Cadastro n�o encontrado");
                        }
                        else
                            System.out.println("Op��o Inv�lida!");
                        break;
                        
                case 5: System.out.println("Informe o nome do cliente: ");
                        s2=e.nextLine();
                        s2=e.nextLine();
                        c=listaC.pesquisaCliente(s2);
                        if (c!=null) {
                            s4 = listagem.pesquisaCompraCliente(c);
                            System.out.println(s4);
                            c=listaC.pesquisaCliente(s2);
                            System.out.println("Fatura do cart�o do cliente: ");
                            System.out.println("\nTotal a pagar pelo cliente: ");
                            System.out.println(listagem.pesquisaCompraTotalPagar(c));
                        }
                        else System.out.println("Cadastro n�o encontrado");
                        
                        break;
                        
                case 6: s3=listagem.pesquisaClienteInativo();
                        System.out.println("Lista dos Clientes Inativos: \n"+s3);
                        break;
                        
                case 7: System.out.println("\n"+listaP.listProduto());
                        break;
                        
                case 8: listagem.descontoAniversario();
                        System.out.println("Gerado desconto aos aniversariantes!");
                        break;
                
                case 9: //d1=listagem.lucroVendas()-listaP.gastoProduto();
                            
            }
        }
                while(opcao!=0);
            }
        
    
}