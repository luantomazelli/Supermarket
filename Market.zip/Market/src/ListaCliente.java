import java.util.*;


public class ListaCliente{
    
    private ArrayList<Cliente> listaC;
    
    public ListaCliente(int m){
        listaC = new ArrayList<Cliente>(m);
    }
    
    public int tamanhoListaC(){
        return listaC.size();
    }
    
    public boolean adicionaCliente(Cliente p){
        return listaC.add(p);
    }
    
    public Cliente buscaCliente(int t){
        return listaC.get(t);
    }

    public boolean removeClienteCpf(String n){
        boolean removeu = false;
        for (int i=0;i<listaC.size();i++){
            Cliente p = listaC.get(i);
            if(p.getCpf().equals(n)){
                listaC.remove(i);
                removeu=true;
                break;
            }
        }
        return removeu;
    }    
    
    public boolean removeClienteNome(String n){
        boolean removeu = false;
        for (int i=0;i<listaC.size();i++){
            Cliente p = listaC.get(i);
            if(p.getNome().equals(n)){
                listaC.remove(i);
                removeu=true;
                break;
            }
        }
        return removeu;
    }    
    
    public Cliente pesquisaClienteCartao(int n){
        int c=-1;
        for (int i=0;i<listaC.size();i++){
            Cliente p = listaC.get(i);
            if (p.getNumeroCartao()==n){
                c=i;
                break;
            }
        }
        if(c!=-1)return listaC.get(c);
        else return null;
    }      
    
    public Cliente pesquisaCliente(String n){
        int c=-1;
        for (int i=0;i<listaC.size();i++){
            Cliente p = listaC.get(i);
            if (p.getNome().equals(n)){
                c=i;
                break;
            }
        }
        if(c!=-1)return listaC.get(c);
        else return null;
    }        
    
    public Cliente pesquisaClienteCpf(String n){
        int c=-1;
        for (int i=0;i<listaC.size();i++){
            Cliente p = listaC.get(i);
            if (p.getCpf().equals(n)){
                c=i;
                break;
            }
        }
        if(c!=-1)return listaC.get(c);
        else return null;
    }            
    
    
    public String listCliente(){
        String str="\n";
        for(int i=0;i<listaC.size();i++){
            str=str+"\nCliente: \n"+listaC.get(i).toString();
        }
        return str;
    }
      
}