public class Telefone{
    private String telefone;
    
    public Telefone(String t){
        setTelefone(t);
    }
    
    public void setTelefone(String t){
        telefone = t;
    }
    
    public String getTelefone(){
        return telefone;
    }
    
    public String toString(){
        return getTelefone();
    }
}