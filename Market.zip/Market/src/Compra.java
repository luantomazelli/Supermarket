import java.util.*;

public class Compra{
    private double dinheiroTotal;
    private double troco;
    private ListaProduto lista = new ListaProduto(10);
    private ListaQuantidade listaQ = new ListaQuantidade(10);
    private double totalPagar;
    private Cliente nCliente;
    private double cheque;
    private String clienteCheque="",clienteDinheiro=""; 
    private GregorianCalendar data;
    
    public Compra(double dT, double t, ListaProduto listaP, ListaQuantidade listaQuan, double tP, Cliente nC, double c, String cc, String cd){
        setListaProduto(listaP);
        setListaQuantidade(listaQuan);
        setDinheiroTotal(dT);
        setTroco(t);
        setTotalPagar(tP);
        setCliente(nC);
        setCheque(c);
        setClienteCheque(cc);
        setClienteDinheiro(cd);
        data = new GregorianCalendar();
    }
    
    public String getData(){
        return ""+data.DAY_OF_MONTH+"/"+data.MONTH+"/"+data.YEAR;
    }
    
    public String getDataMes(){
        return ""+data.MONTH;
    }
    
    public void setClienteCheque(String cC){
        clienteCheque = clienteCheque+"\n"+cC;
    }
    
    public void setClienteDinheiro(String cD){
        clienteDinheiro = clienteDinheiro+"\n"+cD;
    }
    
    public String getClienteDinheiro(){
        return clienteDinheiro;
    }
    
    public String getClienteCheque(){
        return clienteCheque;
    }
    
    public ListaProduto getListaProduto(){
        return lista;
    }
    
    public ListaQuantidade getListaQuantidade(){
        return listaQ;
    }    
    
    
    public void setListaProduto(ListaProduto lp){
        lista = lp;
    }
    
    public void setListaQuantidade(ListaQuantidade lq){
        listaQ = lq;
    }
    
    public void setDinheiroTotal(double dT){
        dinheiroTotal = dT;
    }
    
    public void setTroco(double t){
        troco = t;
    }    
    
    public void setTotalPagar(double tP){
        totalPagar = tP;
    }    
    
    public void setCliente(Cliente c){
        nCliente = c;
    }    
    
    public void setCheque(double c){
        cheque = c;
    }    
    
    public double getDinheiroTotal(){
        return dinheiroTotal;
    }    
    
    public double getTroco(){
        return troco;
    }        
    
    public double getTotalPagar(){
        return totalPagar;
    }        
    
    public Cliente getCliente(){
        return nCliente;
    }        
    
    public double getCheque(){
        return cheque;
    }   
    
    public String toString(){
        return "\nDinheiro Total: "+getDinheiroTotal()+
               "\nTroco: "+getTroco()+
               "\nListas de Produtos: \n"+lista.listProduto()+
               "\nQuantidades dos produtos: \n"+listaQ.listQuantidade()+
               "\nCliente: \n"+nCliente.toString()+
               "\nTotal a pagar: "+totalPagar;
    }    
            
    
    
        
}