import java.util.*;


public class ListaCompra{
    
    private ArrayList<Compra> lista;
    
    public ListaCompra(int m){
        lista = new ArrayList<Compra>(m);
    }
    
    public int tamanhoLista(){
        return lista.size();
    }
    
    public boolean adicionaCompra(Compra p){
        return lista.add(p);
    }
    
    public Compra buscaCompra(int t){
        return lista.get(t);
    }

    public String listCompra(){
        String str="\n";
        for(int i=0;i<lista.size();i++){
            str=str+"\nCompra: \n"+lista.get(i).toString();
        }
        return str;
    }
    
    public String pesquisaCompraCliente(Cliente n){
        String str = "";
        for (int i=0;i<lista.size();i++){
            Compra p = lista.get(i);
            if (p.getCliente()==n){
                str=str+"\n"+lista.get(i);
            }
        }
        return str;
    }
    
    public double pesquisaCompraTotalPagar(Cliente c){
        double tot=0;
        for (int i=0;i<lista.size();i++){
            Compra p = lista.get(i);
            if (p.getCliente()==c)
                tot=tot+p.getTotalPagar();
        }
        return tot;
    }
    
/*    public String pesquisaClienteInativo(String n){
        String str = "";
        for (int i=0;i<lista.size();i++){
            Compra p = lista.get(i);
            if (p.getCliente().getNome().equals(n))
                str=str+"\n"+lista.get(i);
        }
        return str;
    }*/    
    
    public String pesquisaClienteInativo(){
        String str = "";
        GregorianCalendar d = new GregorianCalendar();
        for (int i=0;i<lista.size();i++){
            Compra p = lista.get(i);
                if (p.getDataMes().equals(d.get(Calendar.MONTH)))
                    str=str+"\n"+lista.get(i).getCliente();
        }
        return str;
    }
    
    public void descontoAniversario(){
        GregorianCalendar d = new GregorianCalendar();
        for (int i=0;i<lista.size();i++){
            Compra p = lista.get(i);
            if (p.getCliente().getDataMes()==d.get(Calendar.MONTH+1))
                p.setTotalPagar(p.getTotalPagar()-(p.getTotalPagar()*0.1));
        }
    }
}