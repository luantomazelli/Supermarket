import java.util.Scanner;

public class Supermercado{


    public static void main(String args[]){      
    
        InterfaceCadastro chama = new InterfaceCadastro();
        
        chama.Cadastro();
    }
}