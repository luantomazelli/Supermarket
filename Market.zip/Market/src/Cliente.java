import java.util.*;

public class Cliente{
    private String cpf;
    private String nome;
    private String endereco;
    private Telefone telRes;
    private Telefone telCel;    
    private String cidade;
    private String estado;
    private String bairro;
    private GregorianCalendar data;
    private Cartao cartaoCredito;

   
    public Cliente(String c, String n, String e, Telefone tR, Telefone tC, String cid, String est, String bair, GregorianCalendar d, Cartao cC){
        setCpf(c);
        setNome(n);
        setEndereco(e);
        setTelRes(tR);
        setTelCel(tC);
        setCidade(cid);
        setEstado(est);
        setBairro(bair);
        setData(d);
        setCartaoCredito(cC);
    }
    
    public void setCartaoCredito(Cartao cC){
        cartaoCredito = cC;
    }
    
    public void setCpf(String c){
        cpf = c;
    }
    
    public void setNome(String n){
        nome = n;
    }
    
    public void setEndereco(String e){
        endereco = e;
    }
    
    public void setTelRes(Telefone tR){    
        telRes = tR;
    }
    
    public void setTelCel(Telefone tC){    
        telCel = tC;
    }
 
    public void setCidade(String c){
        cidade = c;
    }    
    
    public void setEstado(String e){
        estado = e;
    }    
    
    public void setBairro(String b){
        bairro = b;
    }    
    
    public void setData(GregorianCalendar d){
        data = d;
    }
    
    public String getCpf(){
        return cpf;
    }
    
    public String getNome(){
        return nome;
    }
    
    public String getEndereco(){
        return endereco;
    }
    
    public Telefone getTelRes(){    
        return telRes;
    }
    
    public Telefone getTelCel(){    
        return telCel;
    }
 
    public String getCidade(){
        return cidade;
    }    
    
    public String getEstado(){
        return estado;
    }    
    
    public String getBairro(){
        return bairro;
    }        
    
    public String getData(){
        return data.get(Calendar.DAY_OF_MONTH)+"/"+data.get(Calendar.MONTH)+"/"+data.get(Calendar.YEAR);
    }    
    
    public int getDataMes(){
        return data.MONTH;
    }
    
    public int getNumeroCartao(){
        return cartaoCredito.getNroCartao();
    }
    
    public String toString(){
        return "\nCpf: "+getCpf()+
               "\nNome: "+getNome()+
               "\nData de Nascimento: "+getData()+
               "\nEndere�o: "+getEndereco()+
               "\nTelefone Residencial: "+getTelRes()+
               "\nTelefone Celular: "+getTelCel()+
               "\nCidade: "+getCidade()+
               "\nEstado: "+getEstado()+
               "\nBairro: "+getBairro()+
               "\nCartao: "+cartaoCredito.getNroCartao();
            }
    
}